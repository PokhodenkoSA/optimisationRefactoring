# Gmsh mesh file format [LAST UPDATE: 23.01.2014]

MgOpt is supporting 3D meshes of gmsh file format. The structure is as follows:
see: [Gmsh Manual](http://geuz.org/gmsh/doc/texinfo/gmsh.html)

```
$MeshFormat
2 0 8
$EndMeshFormat
$Nodes
671
       1   1.061724191831963e+00  -3.304167711219860e-02   1.206615313431720e+00
       2   4.321229903487023e+00   2.610821497494897e+00   2.880146426307296e+00
       .
       .
       .
     670   7.788988907842891e-01   1.000000000000001e+01   1.216452097117070e+01
     671   2.000000000000000e+01  -7.891495456843640e-01   8.257560193015383e+00
$EndNodes
$Elements
3826
1 4 3 7 7 0 540 667 662 522
2 4 3 7 7 0 541 600 555 542
.
.
.
3397 2 6 3 3 0 0 137 1 663 522 521
3398 2 6 3 3 0 0 1 3 540 522 662
.
.
.
3825 2 6 7 7 0 0 2780 2 591 490 491
3826 2 6 7 7 0 0 289 4 490 489 593 
$EndElements
$MGconn % node number, nearest coarse grid node, containing coarse grid element
671
1 482 630
2 1 432
.
.
.
670 641 57
671 642 3
$EndMGconn
```

There are two main parts of typical gmsh file plus additional one for multigrid connectivity information. The part below shows the same file as above with described each part of the file:

1\. Nodes:
```
$Nodes   -> node key word - for reader to easily locate node related data
671      -> total node number
Below we have:       
       ID  X-coordinate            Y-coordinate            Z-coordinate 
       1   1.061724191831963e+00  -3.304167711219860e-02   1.206615313431720e+00
       .
       .
     671   2.000000000000000e+01  -7.891495456843640e-01   8.257560193015383e+00
$EndNodes
```

2\. Elements
```
$Elements -> element key word - for reader to easily locate element related data
3826      -> total element count

List of 3D elements (in this case tetrahedron):

Id    |  ElementType | NumberOfTags | tag(1) | tag(2) | tag(3) | Element-FormingNodes   |
------|--------------|--------------|--------|--------|--------|------------------------|
1     |       4      |      3       |   7    |   7    |    0   | 540   667   662   522  |
.
.
List of 2D elements (in this case triangles):

Id,   |  ElementType | NumberOfTags |tag(1)|tag(2)|tag(3)|tag(4)|tag(5)|tag(6)| Element-FormingNodes |
------|--------------|--------------|------|------|------|------|------|------|----------------------|
3397  |      2       |      6       |   3  |   3  |   0  |   0  |  1   |  137 |   663   522   521    |    
.     |              |              |      |      |      |      |      |      |                      |
.     |              |              |      |      |      |      |      |      |                      |
3826  |      2       |      6       |   7  |   7  |   0  |   0  | 289  |   4  |   490   489   593    |
$EndElements
```

3\. Multigrid connecitivity:
```
$MGconn 
671 -> total number of nodes for current mesh
ID    NearestCoarseGridNode    ContainingCoarseGridElement
1     482                      630
.
.
671   642                      3
$EndMGconn
```
Explanantion of tags. Note that 3D elements have less tags than 2D elements. Hovewer first three means the same for 2D (edge, face) and 3D (tetrahedron, hexahedron, prism, pyramid) elements:

```
1. tag(1) - (used by mgOpt) ID of physical group (boundary set) that the element belongs to
2. tag(2) - (not used by mgOpt) ID of the elementary geometrical entity to which the element belongs
3. tag(3) - (not used by mgOpt) Number of mesh partition the elemnet belongs to
4. tag(4) - 
5. tag(5) - (used by mgOpt) ID of internal element that the face (in 2D: edges, 3d - faces) belongs to 
6. tag(6) - (used by mgOpt) Face ID of the boundary face for internal element specified in tag(5).
```

Gmsh element ID and its corresponding type vs mgOpt element type is presented in the table below (only mgOpt supported elements):
```
ElementType     |  gmsh-ID  |  mgOpt-ID  |  FormingVerticeNumber |
----------------|-----------|------------|-----------------------|
Edge (line)     |     1     |     1      |            2          |
Triangle        |     2     |     2      |            3          |
Quadraliteral   |     3     |     3      |            4          |
Tetrahedron     |     4     |     4      |            4          |
Pyramid         |     7     |     5      |            5          |
Prism           |     6     |     6      |            6          |
Hexahedron      |     5     |     7      |            8          |
```

For more information about gmsh please refer to:
http://geuz.org/gmsh/doc/texinfo/gmsh.html
