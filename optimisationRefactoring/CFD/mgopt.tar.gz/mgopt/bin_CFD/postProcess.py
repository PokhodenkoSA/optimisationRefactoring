#!/usr/bin/env python

# This script parallelises mgOpt. There are a few assumptions that have to hold
# if this is supposed to work.
#
# We assume that Tapenade does not understand the meaning of OpenMP pragmas
# and treats them as ordinary comments. This is true as of Tapenade 3.10, March 2015.
#
# A loop that shall be parallelised has to look as follows:
# do *=*,*
#   call *_loopbody*
# end do
# The adjoint code will then get an OpenMP pragma prepended by this script.
# It is assumed that the calls to loopbody will not have any conflicting writes,
# make sure this is true for your code. All arguments of *loopbody*() will
# be shared between all threads!

# A few problems that can be fixed by implementing a parallel stack properly:
#
# The subroutine *loopbody* has to be simple enough so that Tapenade will not
# push or pop anything to the stack, except the control stack. In particular,
# it is bad if your code overwrites any variable after initialising it. Check
# the output of Tapenade to see if your *loopbody*_b subroutine does not call
# pushinteger or pushreal in any way.
#
# All subroutines of loopbody and their subroutines have to be called *_omp
# if they make any calls to push/pop

import re
import sys
if(len(sys.argv) < 2) or not (sys.argv[1] == 'b' or sys.argv[1]=='d'):
  print('Usage: ./postProcess.py [b|d]')
  sys.exit(-1)

diffSuffix = sys.argv[1]

pushctrlRE = re.compile('pushcontrol[1-9][0-9]*'+diffSuffix,re.IGNORECASE)
popctrlRE = re.compile('popcontrol[1-9][0-9]*'+diffSuffix,re.IGNORECASE)
resumeRE = re.compile('call resumetimer__'+diffSuffix+'[0-9a-z_]*',re.IGNORECASE)
pauseRE = re.compile('call pausetimer__'+diffSuffix+'[0-9a-z_]*',re.IGNORECASE)

with open('allDiff_'+diffSuffix+'.f90', 'r') as sourcefile:
  with open('allDiff_'+diffSuffix+'_post.f90', 'w') as targetfile:
    lastline = ''
    isInsideLoopbody = False
    for line in sourcefile:
      # leave fortran comment lines unchanged
      if not (len(line) == 0 and line.strip()[0] == '!'):
        # skip lines that contain OpenMP pragmas. Tapenade does not understand
        # what it is doing and dumps them all over the place, so we remove them all.
        if ('!$omp' in line.lower()):
          line = '! removed by post-processing: '+line
        if(diffSuffix == 'b'):
          # Put OpenMP statements back in, but only where we want them, that is:
          # at places where a subroutine called *loopbody* is called, we put
          # an OpenMP pragma two lines above, which should be above the do loop.
          # Yes, this is a bit crude.
          if ('call ' in line.lower() and '_loopbody' in line.lower()):
            targetfile.write('!$OMP PARALLEL DO DEFAULT(SHARED)\n')
          # The other problem we need to fix: calls to the Tapenade push/pop stack
          # are not thread-safe. Inside subroutines that are called *_loopbody*,
          # we replace calls to the Tapenade stack by calls to our own, parallel
          # stack.
          if ('subroutine ' in line.lower() and any(s in line.lower() for s in ('_loopbody', '_omp'))):
            isInsideLoopbody = True
          if ('end subroutine' in line.lower()):
            isInsideLoopbody = False
          if(isInsideLoopbody):
            if('implicit none' in line.lower()):
              # our parallel stack module must be available, as well as the
              # OpenMP library to call omp_get_thread_num().
              # We put the correct USE statement just before the implicit none
              # statement. Make sure there is one, or the resulting code
              # might not compile.
              line = 'use openmpstack\n'+line
            # reroute calls to the Tapenade stack to our own, parallel stack
            line = pushctrlRE.sub('PUSHCTRL_OMP',line)
            line = popctrlRE.sub('POPCTRL_OMP',line) 
            line = line.replace('PUSHCONTROL','PUSHCTRL_OMP')
            line = line.replace('POPCONTROL','POPCTRL_OMP')
            line = line.replace('PUSHREAL4','PUSHREAL8_OMP')
            line = line.replace('POPREAL4','POPREAL8_OMP')
            line = line.replace('PUSHREAL8','PUSHREAL8_OMP')
            line = line.replace('POPREAL8','POPREAL8_OMP')
            line = line.replace('PUSHREAL16','PUSHREAL8_OMP')
            line = line.replace('POPREAL16','POPREAL8_OMP')
            line = line.replace('PUSHINTEGER4','PUSHINT4_OMP')
            line = line.replace('POPINTEGER4','POPINT4_OMP')
            line = line.replace('PUSHINTEGER8','PUSHINT4_OMP')
            line = line.replace('POPINTEGER8','POPINT4_OMP')
            line = line.replace('PUSHINTEGER816','PUSHINT4_OMP')
            line = line.replace('POPINTEGER16','POPINT4_OMP')
            # reroute calls to the dummy timer routines to our actual timer routines
          # for differentiated code.
          line = line.replace('USE M04_TIMER_'+diffSuffix,'use m04_timer')
          line = resumeRE.sub('CALL RESUMETIMER_'+diffSuffix,line)
          line = pauseRE.sub('CALL PAUSETIMER_'+diffSuffix,line)
          line = line.replace('CALL RESUMETIMER_(','CALL RESUMETIMER(')
          line = line.replace('CALL PAUSETIMER_(','CALL PAUSETIMER(')
        else: # tangent-linear
          line = line.replace('CALL RESUMETIMER','!removed by postp: RESUMETIMER')
          line = line.replace('CALL PAUSETIMER','!removed by postp: PAUSETIMER')
        # line is finished. store it as last line, print last line
        targetfile.write(lastline)
        lastline = line
    targetfile.write(lastline)
