#!/usr/bin/env python

import json
import os
import shutil
import modRegress
import sys
import re

# Requires definition in command arguments of json data:
#   - json file
#   - compile/nocompile
#   - designPatch for validation: to know in which patch the design info is to be read
#   - 

# @author ..-..-....: Mateusz Gugala - create based on Jan`s regression script


# some file locations. execdir and refdir should only affect
# the internals of this regression check. compiledir has to be
# changed if the regression check or the bin folder is moved.
curdir = os.path.dirname(os.path.realpath(sys.argv[0]))
execdir = curdir+os.sep+'executables'
compiledir = curdir+os.sep+'../../bin'

# names of executables. Used for compilation and mgopt run
mgoptKey  = 'mgopt'
# define tolerance. if the error is larger, the test counts as failed
abstol = 1e-10
timetol = 1.05 # only 5 percent slowdown is acceptable


############################
# Command params
############################
firstOptionalArg=3
usagestring = ' \nusage: \n./sensitivityValidation.py <json file> <[no]compile> investigateResults ("json.option=(\'all\',\'possible\',\'options\')")* \n\n'
usageInfo = 'info: \ninvestigateResults is optional parameter. If not specified by the user the default is: no results output. \n'
errMessage = '\nWrong usage of script. Check info below and retry. \n\n'

if(len(sys.argv)<firstOptionalArg):
  sys.exit(modRegress.bcolors.FAIL+errMessage+modRegress.bcolors.ENDC+usagestring+usageInfo)

templateFile = sys.argv[1]
griddir = os.path.dirname(templateFile)
investigationdir = curdir+os.sep+griddir

if(sys.argv[2]=='nocompile'):
  compile = 0
elif(sys.argv[2]=='compile'):
  compile = 1
  if not(os.path.exists(execdir)):
    os.mkdir(execdir)
else:
  sys.exit(modRegress.bcolors.FAIL+errMessage+modRegress.bcolors.ENDC+usagestring+usageInfo)


############################
# Optional command line arguments: 
############################

firstJsonArg = firstOptionalArg
# (Optional) store results for user investigation (primal.msh, primal/adjoint.cnv, base json file)
if any("investigateResults" in arg for arg in sys.argv):
  investigateResults = 1
  investigationdir = modRegress.utils.createInvestigationDirectory(investigationdir, 'sensitivity')
  firstJsonArg   = firstJsonArg + 1
else:
  investigateResults = 0


# Check json parameters index (have to handle no json inputs also)
jsonArgIndex = (jsonArgIndex for jsonArgIndex, arg in enumerate(sys.argv) if('=(' in arg)).next()
if(firstJsonArg!=(jsonArgIndex)): 
  errMessage=' \nOne of optional parameters was not specified correctly. Check for misspelland rerun. \n'
  sys.exit(modRegress.bcolors.FAIL+errMessage+modRegress.bcolors.ENDC+usagestring+usageInfo)


# check if the appendVectorH5 executable exist
if ( not(os.path.isfile('appendVectorH5') and os.access('appendVectorH5', os.X_OK)) ):
  errMessage= ' Compile the (scalar2vectorH5.f90) file first using the following command: \n'+\
              ' gfortran -o appendVectorH5 scalar2vectorH5.f90 -I$HOME/hdf5-gnu/include/ -L$HOME/hdf5-gnu/lib -lhdf5_fortran -lhdf5'
  sys.exit(modRegress.bcolors.FAIL+errMessage+modRegress.bcolors.ENDC+usagestring+usageInfo)


############################
# Compile mgopt
############################
if(compile):
  modRegress.compile.compilemgopt(compiledir, execdir, mgoptKey)


############################
# generate list of settings
############################
with open(templateFile) as infile:
  templateSettings = json.load(infile)
templateSettings["outputFiles"]["writeRegression"] = 1
settingsList = modRegress.arguments.permuteJsonArguments(templateSettings,sys.argv,firstJsonArg)
# copy executables and template json file to investigation directory
if(investigateResults):
  try:
    modRegress.utils.syscall('cp '+templateFile+' '+investigationdir+os.sep+'settingsTemplate.json', ' ')
    if(compile):
      modRegress.utils.syscall('cp '+execdir+os.sep+mgoptKey+' '+investigationdir+os.sep+'.', ' ')
  except:
    ################################## modify
    print(modRegress.bcolors.FAIL+'\nUnexpected error: '+ sys.exc_info()[0]+modRegress.bcolors.ENDC+'\n')
    

############################
# run validation for each settings permutation
############################
convergenceFiles=[]

for setting in settingsList:

  fileIdentifier = modRegress.arguments.fileIdentifier(setting)
  workdir        = 'workdir'+fileIdentifier

  try:
    os.mkdir(workdir)

    # copy only mesh files to temporary dir (do not use *.msh as the primal and adjoitn results can also have msh extension)
    modRegress.utils.copyMeshes(griddir, workdir, setting, fileIdentifier)

    # run mgopt
    sensitivity_adj_adjx, sensitivity_adj_tanx, sensitivity_tan_tanx, sensitivity_tan_adjx, sensitivity_fd = \
                                                                modRegress.run.sensitivityTest(setting,\
                                                                workdir,\
                                                                griddir,\
                                                                execdir,\
                                                                investigationdir,\
                                                                fileIdentifier,\
                                                                mgoptKey,\
                                                                investigateResults)

    modRegress.test.sensitivityTest(sensitivity_adj_adjx, sensitivity_adj_tanx, sensitivity_tan_tanx,\
                                    sensitivity_tan_adjx, sensitivity_fd, fileIdentifier, setting)
        
  except:
    print "Unexpected error:", sys.exc_info()[0]
    raise
  finally:
    #print workdir       
    #print os.system('pwd')
    #print os.system('ls')
    shutil.rmtree(workdir)
