import modRegress
import os
import json
import sys
import shutil
from pprint import pprint

######################
# post processing: store results, plot data
# @author 21-01-2015: Mateusz Gugala - create 
######################


######################
# store results i.e. solution fields (*.msh) convergence data (*.cnv) and 
# base json file in folder tagged with current date and appropriate suffix
# @author 21-01-2015: Mateusz Gugala - create 
######################
def storeMgoptResults(workdir, investigationdir, fileID, jsonSetting, runMode, caseID):

  # copy all files from work dir
  modRegress.utils.syscall('cp '+workdir+os.sep+'* '+investigationdir+os.sep+'.', caseID)
  
  # --- gnuplot: plot convergence graphs
  if runMode == 1 or runMode == 2:
    cnvFile = jsonSetting["outputFiles"]["primalConvergence"]
    plotCnv(investigationdir, cnvFile, fileID, caseID)
  elif runMode == 3 or runMode == 4:
    cnvFile = jsonSetting["outputFiles"]["dualConvergence"]
    plotCnv(investigationdir, cnvFile, fileID, caseID)


######################
# plot convergence curves for all run cases using convergence data (*.cnv) 
# @author 21-01-2015: Mateusz Gugala - create 
######################
def plotCnv(investigationdir, cnvFile, fileID, caseID):
  
  curdir = os.getcwd()
  os.chdir(investigationdir)

  scriptName = 'plot.gp'
  
  gnuplotScript = open(scriptName,'w')
  fileToPlot    = str(cnvFile)

  # Plot rms(iter)   
  rmsiFileName = str(fileID)+'_rmsI.png'
  gnuplotScript.write(os.linesep)
  gnuplotScript.write('set xlabel \"Iteration/Cycles [-]\"'+os.linesep)
  gnuplotScript.write('set ylabel \"log(rms) [-]\"'+os.linesep)
  gnuplotScript.write('set grid'+os.linesep)
  gnuplotScript.write('set title \"CASE: '+str(fileID)+'\"'+os.linesep)
  gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
  gnuplotScript.write('set out \"'+rmsiFileName+'\"'+os.linesep)
  x=0
  gnuplotScript.write('plot \"'+fileToPlot+'\" u '+str(x)+':3 w l title \"log(rmsRho)\", '+\
                                         '\"\" u '+str(x)+':4 w l title \"log(rmsRhoU)\", '+\
                                         '\"\" u '+str(x)+':5 w l title \"log(rmsRhoV)\", '+\
                                         '\"\" u '+str(x)+':6 w l title \"log(rmsRhoW)\", '+\
                                         '\"\" u '+str(x)+':7 w l title \"log(rmsRhoE)\", '+\
                                         '\"\" u '+str(x)+':8 w l title \"log(rmsSA)\"'+os.linesep)


  # Plot rms(time)
  rmstFileName = str(fileID)+'_rmsT.png'
  gnuplotScript.write(os.linesep)
  gnuplotScript.write('set xlabel \"Time [min]\"'+os.linesep)
  gnuplotScript.write('set out \"'+rmstFileName+'\"'+os.linesep)
  x=2
  gnuplotScript.write('plot \"'+fileToPlot+'\" u '+str(x)+':3 w l title \"log(rmsRho)\", '+\
                                         '\"\" u '+str(x)+':4 w l title \"log(rmsRhoU)\", '+\
                                         '\"\" u '+str(x)+':5 w l title \"log(rmsRhoV)\", '+\
                                         '\"\" u '+str(x)+':6 w l title \"log(rmsRhoW)\", '+\
                                         '\"\" u '+str(x)+':7 w l title \"log(rmsRhoE)\", '+\
                                         '\"\" u '+str(x)+':8 w l title \"log(rmsSA)\"'+os.linesep)


  # Plot Cl(iter), Cd(iter)
  clcdFileName = str(fileID)+'_clcd.png'
  gnuplotScript.write(os.linesep)
  gnuplotScript.write('set xlabel \"Iteration/Cycles [-]\"'+os.linesep)
  gnuplotScript.write('set ylabel \"Cl [-]\"'+os.linesep)
  gnuplotScript.write('set y2label \"Cd [-]\"'+os.linesep)
  gnuplotScript.write('set ytics nomirror'+os.linesep)
  gnuplotScript.write('set y2tics nomirror'+os.linesep)
  gnuplotScript.write('set out \"'+clcdFileName+'\"'+os.linesep)
  x=0
  gnuplotScript.write('plot \"'+fileToPlot+'\" u '+str(x)+':9 w l title \"Cl\" axes x1y1, '+\
                                         '\"\" u '+str(x)+':10 w l title \"Cd\" axes x1y2'+os.linesep)

  

  # close created plot.gp script
  gnuplotScript.close()

  # run created script
  modRegress.utils.syscall('gnuplot '+scriptName, caseID)
  #modRegress.utils.syscall('rm '+investigationdir+os.sep+scriptName)

  os.chdir(curdir)


######################
# plot validation curves for flat plate cases using convergence data (*.cnv) 
# @author 21-01-2015: Mateusz Gugala - create 
######################
def plotValidation(investigationdir, valFiles):
  
  scriptName = 'plotValidation.gp'
  refResultsDir = investigationdir+os.sep+'../refResults'
  coarse = '35x25'
  medium = '137x97'
  fine   = '545x385'

  for valFile in valFiles:
  
    if coarse in valFile:
      caseTitle = coarse     
    elif medium in valFile:
      caseTitle = medium
    elif fine in valFile:
      caseTitle = fine
    else:
      errMessage = '\nError: no correct case title for flatPlate validation.'
      sys.exit(modRegress.bcolors.FAIL+errMessage+modRegress.bcolors.ENDC)

    gnuplotScript = open(investigationdir+os.sep+scriptName,'w')
    fileToPlot= str(investigationdir)+os.sep+str(valFile)+'.dat'

    # Plot friction coefficient   
    plotName = 'Cf_'+str(valFile)+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"x [m]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"Cf [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set yrange[0.002:0.006]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"Cf(x), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u 1:2 w p title \"'+str(caseTitle)+'\"'+\
                       ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D_CF.dat\" u 1:2 title \"NASA\" w l'+os.linesep)

    # Plot u+(y+) section [1,2]
    # Section 1
    plotName = 'yplusUplusSec1_'+str(valFile)+'.png'
    gnuplotScript.write('a = log(10**(1.0/0.41))'+os.linesep)
    gnuplotScript.write('b = log(100.0)/0.41+5-log(10**(2.0/0.41))'+os.linesep)

    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"log(y+) [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"u+ [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set xrange[-1:5]'+os.linesep)
    gnuplotScript.write('set yrange[0:30]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"u+(log(y+)) (x=0.97008m), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u (log10($7)):8 w p title \"'+str(caseTitle)+'\"'+\
                        ', 10**(x) w l title "SPALDING-linear", ( 0.1 < x && x < 30000 ) ?a*x+b : 1/0 title "SPALDING-log"'+os.linesep)

    # Section 2
    plotName = 'yplusUplusSec2_'+str(valFile)+'.png'
    gnuplotScript.write('set title \"u+(log(y+)) (x=190334m), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u (log10($12)):13 w p title \"'+str(caseTitle)+'\"'+\
                         ', 10**(x) w l title "SPALDING-linear", ( 0.1 < x && x < 30000 ) ?a*x+b : 1/0 title "SPALDING-log"'+os.linesep)

    # Plot mut/muinf section [1,2]
    # Section 1
    plotName = 'muTmuInfSec1_'+str(valFile)+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"y [m]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"mu_t/mu_linf [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set yrange[0:0.025]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"mu_t/mu_linf (x=0.97008m), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u 9:5 w p title \"'+str(caseTitle)+'\"'+\
                         ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D.dat\" u 3:2 title \"NASA\" w l'+os.linesep)

    # Section 2
    plotName = 'muTmuInfSec2_'+str(valFile)+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set yrange[0:0.04]'+os.linesep)
    gnuplotScript.write('set title \"mu_t/mu_linf (x=1.90334m), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u 14:10 w p title \"'+str(caseTitle)+'\"')

    # Plot y(Vt) section [1,2]
    # Section 1
    plotName = 'yVtVinfSec1_'+str(valFile)+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"Vt/Vinf [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"y [m]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set xrange[0:1.2]'+os.linesep)
    gnuplotScript.write('set yrange[0:0.02]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"y(Vt/Vinf) (x=0.97008m), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u ($6/69.732288):5 w p title \"'+str(caseTitle)+'\"'+\
                        ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D_uprof.dat\" u 1:2 title \"NASA\" w l'+os.linesep)
    
    # Section 2
    plotName = 'yVtVinfSec2_'+str(valFile)+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set xrange[0:1.2]'+os.linesep)
    gnuplotScript.write('set yrange[0:0.04]'+os.linesep)
    gnuplotScript.write('set title \"y(Vt/Vinf) (x=1.90334m), CASE: '+str(valFile)+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(investigationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot+'\" u ($6/69.732288):5 w p title \"'+str(caseTitle)+'\"'+\
                        ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D_uprof.dat\" u 1:2 title \"NASA\" w l'+os.linesep)

    # close created plot.gp script
    gnuplotScript.close()

    # run created script
    modRegress.utils.syscall('gnuplot '+investigationdir+os.sep+scriptName+' > /dev/null', caseID)
    #modRegress.utils.syscall('rm '+investigationdir+os.sep+scriptName)


# ######################
# # plot validation curves for flat plate cases using convergence data (*.cnv) 
# # @author 21-01-2015: Mateusz Gugala - create 
# ######################
def plotValidationAll(validationdir, sortKeys, caseID):
  
  scriptName = 'plotValidationAll.gp'
  refResultsDir = validationdir+os.sep+'../refResults'
  coarse = '35x25'
  medium = '137x97'
  fine   = '545x385'

  # create validation file list in the form [ [], [], [] ] 
  # where each internal [] has 3 arguments - results for given setup for coarse , medium, fine grid
  iniValFiles =glob.glob(validationdir+os.sep+'*.dat' )
  for i in range(0,len(iniValFiles)):
    iniValFiles[i] = os.path.basename(iniValFiles[i])

  valFiles = []
  for key in sortKeys:
    tempList = []
    for dat in iniValFiles:
      if key in dat:
        tempList.append(dat)
      tempList1 = ['','','']
      for temp in tempList:
        if coarse in temp:
          tempList1[0] = temp
        elif medium in temp:
          tempList1[1] = temp
        elif fine in temp:
          tempList1[2] = temp
    valFiles.append(tempList1)
  
  for valFile in valFiles:
  
    gnuplotScript = open(validationdir+os.sep+scriptName,'w')
    fileToPlot0= str(validationdir)+os.sep+str(valFile[0])
    fileToPlot1= str(validationdir)+os.sep+str(valFile[1])
    fileToPlot2= str(validationdir)+os.sep+str(valFile[2])

    # Plot friction coefficient   
    plotName = 'Cf_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"x [m]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"Cf [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set yrange[0.002:0.006]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"Cf(x), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u 1:2 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u 1:2 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u 1:2 w p title \"545x385\"'+\
                       ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D_CF.dat\" u 1:2 title \"NASA\" w l'+os.linesep)

    # Plot u+(y+) section [1,2]
    # Section 1
    plotName = 'yplusUplusSec1_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write('a = log(10**(1.0/0.41))'+os.linesep)
    gnuplotScript.write('b = log(100.0)/0.41+5-log(10**(2.0/0.41))'+os.linesep)

    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"log(y+) [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"u+ [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set xrange[-1:5]'+os.linesep)
    gnuplotScript.write('set yrange[0:30]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"u+(log(y+)) (x=0.97008m), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u (log10($7)):8 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u (log10($7)):8 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u (log10($7)):8 w p title \"545x385\"'+\
                        ', 10**(x) w l title "SPALDING-linear", ( 0.1 < x && x < 30000 ) ?a*x+b : 1/0 title "SPALDING-log"'+os.linesep)

    # Section 2
    plotName = 'yplusUplusSec2_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write('set title \"u+(log(y+)) (x=190334m), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u (log10($12)):13 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u (log10($12)):13 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u (log10($12)):13 w p title \"545x385\"'+\
                         ', 10**(x) w l title "SPALDING-linear", ( 0.1 < x && x < 30000 ) ?a*x+b : 1/0 title "SPALDING-log"'+os.linesep)

    # Plot mut/muinf section [1,2]
    # Section 1
    plotName = 'muTmuInfSec1_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"y [m]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"mu_t/mu_linf [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set yrange[0:0.025]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"mu_t/mu_linf (x=0.97008m), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u 9:5 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u 9:5 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u 9:5 w p title \"545x385\"'+\
                         ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D.dat\" u 3:2 title \"NASA\" w l'+os.linesep)

    # Section 2
    plotName = 'muTmuInfSec2_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set yrange[0:0.04]'+os.linesep)
    gnuplotScript.write('set title \"mu_t/mu_linf (x=1.90334m), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u 14:10 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u 14:10 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u 14:10 w p title \"545x385\"')

    # Plot y(Vt) section [1,2]
    # Section 1
    plotName = 'yVtVinfSec1_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set xlabel \"Vt/Vinf [-]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set ylabel \"y [m]\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set xrange[0:1.2]'+os.linesep)
    gnuplotScript.write('set yrange[0:0.02]'+os.linesep)
    gnuplotScript.write('set grid'+os.linesep)
    gnuplotScript.write('set title \"y(Vt/Vinf) (x=0.97008m), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u ($6/69.732288):5 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u ($6/69.732288):5 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u ($6/69.732288):5 w p title \"545x385\"'+\
                        ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D_uprof.dat\" u 1:2 title \"NASA\" w l'+os.linesep)
    
    # Section 2
    plotName = 'yVtVinfSec2_'+'All_'+str(valFile[0])+'.png'
    gnuplotScript.write(os.linesep)
    gnuplotScript.write('set autoscale'+os.linesep)
    gnuplotScript.write('set xrange[0:1.2]'+os.linesep)
    gnuplotScript.write('set yrange[0:0.04]'+os.linesep)
    gnuplotScript.write('set title \"y(Vt/Vinf) (x=1.90334m), CASE: '+'All_'+str(valFile[0])+'\" font \"Helvica,12\"'+os.linesep)
    gnuplotScript.write('set term pngcairo size 1200,750'+os.linesep)
    gnuplotScript.write('set output \"'+str(validationdir)+os.sep+plotName+'\"'+os.linesep)

    gnuplotScript.write('plot \"'+fileToPlot0+'\" u ($11/69.732288):10 w p title \"35x25\"'+\
                        ', \"'+fileToPlot1+'\" u ($11/69.732288):10 w p title \"137x97\"'+\
                        ', \"'+fileToPlot2+'\" u ($11/69.732288):10 w p title \"545x385\"'+\
                        ', \"'+str(refResultsDir)+os.sep+'NASA-CFL3D_uprof.dat\" u 3:4 title \"NASA\" w l'+os.linesep)

    # close created plot.gp script
    gnuplotScript.close()

    # run created script
    modRegress.utils.syscall('gnuplot '+validationdir+os.sep+scriptName+' > /dev/null', caseID)
    #modRegress.utils.syscall('rm '+investigationdir+os.sep+scriptName)

