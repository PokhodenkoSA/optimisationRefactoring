import sys
import os
import modRegress.utils
import re 

configFileNameH5 = 'importField.config'
fieldFileNameH5 = 'importField.ascii'
dxFieldName = 'dX' # that corresponds to ficed name in mgopt code (when it changes there it have to be adjusted accordingly
sensitivityFileName = 'volumeSensitivity.ascii'
sensitivityFieldName = 'volumeSensitivity'

######################
# create config file for h5import to append a field in hdf5 file
# @author 26-06-2015: Mateusz Gugala - create 
######################
def configGenerate(nMeshNodes, workdir, jsonSettings):

  solutionFileName = os.path.basename(jsonSettings["outputFiles"]["solution"])
 
  with open(workdir+os.sep+configFileNameH5, 'w') as configFile:
    configFile.write('HDF5 \"'+solutionFileName+'_field.h5\" {'+os.linesep)
    configFile.write('DATASET \"'+dxFieldName+'\" {'+os.linesep)
    configFile.write('   DATATYPE  H5T_IEEE_F64LE'+os.linesep)
    configFile.write('   DATASPACE  SIMPLE { ( 3, '+str(nMeshNodes)+' ) / ( 3, '+str(nMeshNodes)+' ) }'+os.linesep)
    configFile.write('   DATA {'+os.linesep)
    configFile.write('   }'+os.linesep)
    configFile.write('}'+os.linesep)
    configFile.write('}'+os.linesep)
 
  

######################
# create config file for h5import to append a field in hdf5 file
# @author 26-06-2015: Mateusz Gugala - create 
######################
def displacementOutput(nMeshNodes, designNode, designDirection, workdir, jsonSettings, caseID, delta):

  curdir = os.getcwd()
  os.chdir(workdir)

  # --- create displacement field with delta displacement on designNode and direction
  # --- all x coords first then y and z
  x=[0]*3
  with open(fieldFileNameH5, 'w') as theFile:
    for i in range(1,nMeshNodes+1):
      if i == designNode:
        x[designDirection] = delta
        theFile.write(str(x[0])+' '+str(x[1])+' '+str(x[2])+'\n')
      else:                 
        theFile.write(str(0)+' '+str(0)+' '+str(0)+'\n')
  # --- use h5import tool to append displacement field in solution file    
  solutionFileName = os.path.basename(jsonSettings["outputFiles"]["solution"])+'_field.h5'

  modRegress.utils.syscall('../appendVectorH5'+' '+dxFieldName+' '+fieldFileNameH5+' '+solutionFileName+' '+\
                            str(3)+' '+str(nMeshNodes), caseID)   

#  modRegress.utils.syscall('h5import'+' '+fieldFileNameH5+' -config'+' '+configFileNameH5+' -o'+' '+solutionFileName)   

  os.chdir(curdir)


######################
# get sensitivity at design node from solution file - that is very badly implemented but works for now
# @author 26-06-2015: Mateusz Gugala - create 
######################
def getSensitivity(nMeshNodes, designNode, designDirection, jsonSettings, workdir, caseID):

  curdir = os.getcwd()
  os.chdir(workdir)
  solutionFileName = os.path.basename(jsonSettings["outputFiles"]["solution"])+'_field.h5'

  h5call = 'h5dump -o'+' '+sensitivityFileName+' -m \"%.15f\" -d '+\
            sensitivityFieldName+' '+solutionFileName

  modRegress.utils.syscall(h5call, caseID)

  row    = 0
  column = 0
  designEntryID = designNode*3 - (2-designDirection) # numbering starts from 0 and we need direction = designDirection (x = 0, y = 1, z = 2) 
  with open(sensitivityFileName, 'r') as theFile:

    theContent = theFile.readlines()
    iEntry     = 0
    for i in range(0,len(theContent)):

      line = theContent[i]

      # find the right row in file related to chosen design direction
      if '(' in line:
        allFloatsStr = line.split(':')[1]
        allFloats    = re.findall(r"[-+]?\d*\.\d+|\d+", allFloatsStr)

        for Float in allFloats:

          iEntry = iEntry + 1
          if iEntry == designEntryID:
            sensitivity = Float
            break

  os.chdir(curdir)

  return sensitivity
