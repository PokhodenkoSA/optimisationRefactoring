#!/usr/bin/env python
import os
import sys
import math

### SEE README FILE FOR DETAILS ON RUNNING SCRIPT AND COVERED CASES ###

#####################################################################
# This script is created to define all regresion checks for mgOpt and 
# run ./sValidationTest.py script with proper arguments 
# The description on how to run and of cases already set up are in README file

#####################################################################
# @author 26-01-2015: Mateusz Gugala - create
# @author 02-02-2015: Mateusz Gugala - add flat plate and rae2822 tests

# @TODO: 1) create better error handling for wrong input

print ''
print '--- RUNNING SENSITIVITY VALIDATION ---'
print ''

sValidationScriptName = 'sensitivityValidation.py'

# Define lists of settings

# Lists to be looped over
listOfCases     = ['cube/cube.json','deathStar/deathStar.json', 'flatPlate/flatPlate.json', 'rae2822/rae2822.json']
listOfMeshes    = ['cube.', 'deathStar.', 'FlatPlate_35x25.', 'rae2822_Laminar.']
listOfFlowTypes = ['Inviscid', 'Laminar', 'Turbulent']
listOfSolvers   = ['EXPLICIT','BLOCKJACOBI','JTKIRK']
CFLimplicit = 200
CFLexplicit = 1

usagestring = ' \nusage: \n./runSensitivityValidation.py <compile/nocompile> [investigate] \n<> - choose one of the options provided, \n[] - optional arguments \n'

if(len(sys.argv)<2):
  sys.exit(usagestring)


compileMode = sys.argv[1]
if(compileMode!='compile' and compileMode!='nocompile'):
  errMessage='error: wrong input for compile mode <compile/nocompile>'
  sys.exit(errMessage+usagestring)


if any("investigate" in arg for arg in sys.argv):
  investigateSettings = ' '+'investigateResults'
else:
  investigateSettings = ''


# # CASE: cube with gmsh format
case=listOfCases[0]
mesh = listOfMeshes[0]
solver = 'JTKIRK'
iWallTypeWeak='inviscidWallWeak'
iWallTypeHard='inviscidWallHard'
vWallTypeHard='viscousWallHard'
for flow in listOfFlowTypes: 
  if(solver=='EXPLICIT'): 
    CFL = CFLexplicit
    nIterations = 5000
  elif(solver=='BLOCKJACOBI' or solver=='JTKIRK'): 
    CFL = CFLimplicit
    nIterations = 350
  else: 
    print('error')

  plotEveryItCount = max(math.floor(float(nIterations)/50.0), 1)

  sValidationSettings = case+' '+compileMode+' '
  sValidationSettings = sValidationSettings + investigateSettings
  jsonSettings       = 'inputFiles.meshPrefix="(\''+mesh+'\',)"'+' '

  jsonSettings = jsonSettings + \
                 'solverSettings.physics.flowType="(\''+flow+'\')"'+' '+\
                 'solverSettings.physics.unsteady="(0)"'+' '+\
                 'solverSettings.numerics.CFL="('+str(CFL)+')"'+' '+\
                 'solverSettings.numerics.fluxType="(\'ROE\')"'+' '+\
                 'solverSettings.numerics.accuracy="(\'2nd\')"'+' '+\
                 'solverSettings.numerics.multigrid.coarsestMesh="(1)"'+' '+\
                 'solverSettings.convergenceCriteria.numberOfTimeSteps="(1)"'+' '+\
                 'optionalArguments="(1)"'+' '+\
                 'optionalSettings.sensitivityTest="(1)"'+' '
#                 'solverSettings.numerics.limiter.type="(\'none\')"'+' '+\                 
#                 'meshDeformSettings.method="(\'surface\')"'+' '+\  
#                 'solverSettings.convergenceCriteria.numberOfIterations="('+str(nIterations)+')"'+' '+\
#                 'solverSettings.outputInfo.plotResidualEvery="('+str(plotEveryItCount)+')"'+' '+\
#                 'solverSettings.outputInfo.saveResultsEvery="('+str(nIterations)+')"'+' '+\
#                 'solverSettings.numerics.solverType="(\''+solver+'\')"'+' '+\
#                 'solverSettings.numerics.gradientSettings.method="(\'cellBased\')"'+' '+\
  
  if(flow=='Inviscid'): 
    jsonSettings = jsonSettings + \
    'caseSetup.boundaryPatches.patch_1.physicalType="(\''+iWallTypeWeak+'\')"'+' '+\
    'caseSetup.boundaryPatches.patch_6.physicalType="(\''+iWallTypeWeak+'\')"'+' '
    #'caseSetup.boundaryPatches.patch_1.physicalType="(\''+iWallTypeWeak+'\')"'+' '+\
    #'caseSetup.boundaryPatches.patch_6.physicalType="(\''+iWallTypeWeak+'\')"'+' '
  else:
    jsonSettings = jsonSettings + \
    'caseSetup.boundaryPatches.patch_1.physicalType="(\''+vWallTypeHard+'\')"'+' '+\
    'caseSetup.boundaryPatches.patch_6.physicalType="(\''+vWallTypeHard+'\')"'+' '

  # validation info: design surfaces and node 
  jsonSettings = jsonSettings + \
    'caseSetup.boundaryPatches.patch_1.evaluateCostFunction="(1)"'+' '+\
    'caseSetup.boundaryPatches.patch_1.designType="(\'free\')"'+' '+\
    'caseSetup.boundaryPatches.patch_1.designSettings.nodes="(\'1\',\'2\',\'3\',\'4\',\'5\','+\
                                                            '\'6\',\'7\',\'8\',\'9\',\'10\','+\
                                                            '\'11\',\'12\',\'13\',\'14\',\'15\','+\
                                                            '\'16\',\'17\',\'18\',\'19\',\'20\','+\
                                                            '\'21\',\'22\',\'23\',\'24\',\'25\','+\
                                                            '\'26\',\'27\',\'28\',\'29\',\'30\','+\
                                                            '\'31\',\'32\',\'33\',\'34\',\'35\','+\
                                                            '\'36\',\'37\',\'38\',\'39\',\'40\','+\
                                                            '\'41\',\'42\',\'43\',\'44\',\'45\','+\
                                                            '\'46\',\'47\',\'48\',\'49\',\'50\','+\
                                                            '\'51\',\'52\',\'53\',\'54\',\'55\','+\
                                                            '\'56\',\'57\',\'58\',\'59\',\'60\','+\
                                                            '\'61\',\'62\',\'63\',\'64\')"'+' '+\
    'caseSetup.boundaryPatches.patch_1.designSettings.direction="(\'x\',\'y\',\'z\')"'+' '+\
    'caseSetup.boundaryPatches.patch_6.evaluateCostFunction="(0)"'+' '+\
    'caseSetup.boundaryPatches.patch_6.designType="(\'fixed\')"'+' '
#   'caseSetup.boundaryPatches.patch_1.designSettings.nodes="(\'50\')"'+' '+\
  
  os.system('./'+sValidationScriptName+' '+sValidationSettings+' '+jsonSettings)
 
  compileMode='nocompile'



  
# # CASE: deathStar
case=listOfCases[1]
mesh = listOfMeshes[1]
solver = 'JTKIRK'
for flow in listOfFlowTypes: 
  if(flow=='Inviscid'): wallType='inviscidWallWeak'
  elif(flow=='Laminar' or flow=='Turbulent'): wallType='viscousWallHard'
  else: print('error')
  
  if(solver=='EXPLICIT'): 
    CFL = CFLexplicit
    nIterations = 5000
  elif(solver=='BLOCKJACOBI' or solver=='JTKIRK'): 
    CFL = CFLimplicit
    nIterations = 350
  else: 
    print('error')

  plotEveryItCount = max(math.floor(float(nIterations)/50.0), 1)

  sValidationSettings = case+' '+compileMode+' '
  sValidationSettings = sValidationSettings + investigateSettings

  jsonSettings       = 'inputFiles.meshPrefix="(\''+mesh+'\')"'+' '+\
           'solverSettings.physics.flowType="(\''+flow+'\')"'+' '+\
           'solverSettings.physics.unsteady="(0)"'+' '+\
           'solverSettings.numerics.CFL="('+str(CFL)+')"'+' '+\
           'solverSettings.numerics.fluxType="(\'ROE\')"'+' '+\
           'solverSettings.numerics.accuracy="(\'1st\',\'2nd\')"'+' '+\
           'solverSettings.numerics.limiter.type="(\'none\')"'+' '+\
           'solverSettings.numerics.multigrid.coarsestMesh="(1)"'+' '+\
           'solverSettings.convergenceCriteria.numberOfTimeSteps="(1)"'+' '+\
           'solverSettings.convergenceCriteria.numberOfIterations="('+str(nIterations)+')"'+' '+\
           'solverSettings.outputInfo.plotResidualEvery="('+str(plotEveryItCount)+')"'+' '+\
           'solverSettings.outputInfo.saveResultsEvery="('+str(nIterations)+')"'+' '\
           'caseSetup.boundaryPatches.patch_7.physicalType="(\''+wallType+'\')"'+' '+\
           'caseSetup.boundaryPatches.patch_8.physicalType="(\''+wallType+'\')"'+' '+\
                            'optionalArguments="(1)"'+' '+\
                            'optionalSettings.sensitivityTest="(1)"'+' '
  

  # validation info: design surfaces and node 
  jsonSettings = jsonSettings + \
    'caseSetup.boundaryPatches.patch_7.evaluateCostFunction="(1)"'+' '+\
    'caseSetup.boundaryPatches.patch_7.designType="(\'free\')"'+' '+\
    'caseSetup.boundaryPatches.patch_7.designSettings.nodes="(\'1526\')"'+' '+\
    'caseSetup.boundaryPatches.patch_7.designSettings.direction="(\'x\',\'y\')"'+' '+\
    'caseSetup.boundaryPatches.patch_7.evaluateCostFunction="(1)"'+' '+\
    'caseSetup.boundaryPatches.patch_7.designType="(\'fixed\')"'+' '+\
  os.system('./'+sValidationScriptName+' '+sValidationSettings+' '+jsonSettings)
  
  compileMode='nocompile'




# # # # CASE: flatPlate
# # case   = listOfCases[2]
# # mesh   = listOfMeshes[2]
# # solver = listOfSolvers[2]

# # for flow in listOfFlowTypes[1:3]:
# #   if(flow=='Inviscid'): wallType='inviscidWallWeak'
# #   elif(flow=='Laminar' or flow=='Turbulent'): wallType='viscousWallHard'
# #   else: print('error')
  
# #   if(solver=='EXPLICIT'): CFL = CFLexplicit
# #   elif(solver=='BLOCKJACOBI' or solver=='JTKIRK'): CFL = CFLimplicit
# #   else: print('error')
  
# #   sValidationSettings = case+' '+runMode+' '+compileMode+' '+'runModes=[1]'
# #   sValidationSettings = sValidationSettings + investigateSettings
# #   jsonSettings       = 'inputFiles.meshPrefix="(\''+mesh+'\')"'+' '+\
# #                        'caseSetup.boundaryPatches.patch_1.physicalType="(\''+wallType+'\')"'+' '+\
# #                        'caseSetup.boundaryPatches.patch_5.physicalType="(\'inviscidWallWeak\')"'+' '+\
# #                        'solverSettings.physics.flowType="(\''+flow+'\')"'+' '+\
# #                        'solverSettings.physics.unsteady="(0)"'+' '+\
# #                        'solverSettings.numerics.solverType="(\''+solver+'\')"'+' '+\
# #                        'solverSettings.numerics.CFL="('+str(CFL)+')"'+' '+\
# #                        'solverSettings.numerics.fluxType="(\'ROE\',\'AUSM\')"'+' '+\
# #                        'solverSettings.numerics.accuracy="(\'2nd\')"'+' '+\
# #                        'solverSettings.numerics.limiter.type="(\'DMV\',\'none\')"'+' '+\
# #                        'solverSettings.numerics.multigrid.coarsestMesh="(1,2)"'+' '+\
# #                        'solverSettings.convergenceCriteria.numberOfTimeSteps="(1)"'+' '+\
# #                        'solverSettings.convergenceCriteria.numberOfIterations="('+str(nIterations)+')"'+' '+\
# #                        'solverSettings.outputInfo.saveResultsEvery="('+str(nIterations)+')"'

# #   if (flow=='Turbulent'):
# #     jsonSettings = jsonSettings + ' solverSettings.numerics.wallDistanceMethod="(\'exactGlobalSearch\', \'diffusionEqn\')"'

# #   os.system('./'+sValidationScriptName+' '+sValidationSettings+' '+jsonSettings)
# #   compileMode='nocompile'



# # CASE: rae2822
case   = listOfCases[3]
mesh   = listOfMeshes[3]
flow   = listOfFlowTypes[1]
solver = listOfSolvers[2]

CFLimplicit = 100 # for 200 AUSM/MG3/JTKIRK diverge

for flow in listOfFlowTypes[1:3]:
  if(flow=='Inviscid'): wallType='inviscidWallWeak'
  elif(flow=='Laminar' or flow=='Turbulent'): wallType='viscousWallHard'
  else: print('error')
  
  if(solver=='EXPLICIT'): 
    CFL = CFLexplicit
    nIterations = 5000
  elif(solver=='BLOCKJACOBI' or solver=='JTKIRK'): 
    CFL = CFLimplicit
    nIterations = 350
  else: 
    print('error')

  plotEveryItCount = max(math.floor(float(nIterations)/50.0), 1)

  sValidationSettings = case+' '+compileMode+' '
  sValidationSettings = sValidationSettings + investigateSettings

  jsonSettings       = 'inputFiles.meshPrefix="(\''+mesh+'\')"'+' '+\
             'caseSetup.boundaryPatches.patch_1.physicalType="(\''+wallType+'\')"'+' '+\
             'caseSetup.boundaryPatches.patch_2.physicalType="(\''+wallType+'\')"'+' '+\
             'solverSettings.physics.flowType="(\''+flow+'\')"'+' '+\
             'solverSettings.physics.unsteady="(0)"'+' '+\
             'solverSettings.numerics.solverType="(\''+solver+'\')"'+' '+\
             'solverSettings.numerics.CFL="('+str(CFL)+')"'+' '+\
             'solverSettings.numerics.fluxType="(\'ROE\')"'+' '+\
             'solverSettings.numerics.accuracy="(\'2nd\')"'+' '+\
             'solverSettings.numerics.gradientSettings.method="(\'cellBased\')"'+' '+\
             'solverSettings.numerics.limiter.type="(\'DMV\')"'+' '+\
             'solverSettings.numerics.multigrid.coarsestMesh="(1)"'+' '+\
             'solverSettings.convergenceCriteria.numberOfTimeSteps="(1)"'+' '+\
             'solverSettings.convergenceCriteria.numberOfIterations="('+str(nIterations)+')"'+' '+\
             'solverSettings.outputInfo.plotResidualEvery="('+str(plotEveryItCount)+')"'+' '+\
             'solverSettings.outputInfo.saveResultsEvery="('+str(nIterations)+')"'+' ' 
  
    # validation info: design surfaces and node 
  jsonSettings = jsonSettings + \
    'caseSetup.boundaryPatches.patch_1.evaluateCostFunction="(1)"'+' '+\
    'caseSetup.boundaryPatches.patch_1.designType="(\'fixed\')"'+' '+\
    'caseSetup.boundaryPatches.patch_2.evaluateCostFunction="(1)"'+' '+\
    'caseSetup.boundaryPatches.patch_2.designType="(\'free\')"'+' '+\
    'caseSetup.boundaryPatches.patch_2.designSettings.nodes="(\'1700\')"'+' '+\
    'caseSetup.boundaryPatches.patch_2.designSettings.direction="(\'x\',\'y\')"'

  os.system('./'+sValidationScriptName+' '+sValidationSettings+' '+jsonSettings)
  compileMode='nocompile'
