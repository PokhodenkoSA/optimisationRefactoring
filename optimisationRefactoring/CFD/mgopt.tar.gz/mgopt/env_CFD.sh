export PATH=$HOME/usrinstalled/tapenade3.11/bin:$HOME/usrinstalled/jre1.8.0_71/bin:$PATH
export JAVA_HOME=$HOME/usrinstalled/jre1.8.0_71
export TAPENADE_HOME=$HOME/usrinstalled/tapenade3.11
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/hdf5-gnu/lib:$HOME/hdf5-intel/lib
