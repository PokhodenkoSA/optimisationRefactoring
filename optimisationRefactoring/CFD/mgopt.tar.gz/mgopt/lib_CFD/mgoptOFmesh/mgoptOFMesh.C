#include "mgoptOFMesh.H"

void init_reader( int *enable_mpi, int *does_mpi_finalize,
                  int *nlevel, int *size_param, 
                  char *param ) {
  char **some = const_cast<char **>(global_arg);
  int num_arg;
  *nlevel = 1; /* No multigrid support for now */
  *does_mpi_finalize = 1; /* True */
  if( *enable_mpi == 1 ) {/* True */
    num_arg = 2;
//    Info << "Enabling MPI run ...";
  }else {  /* False */
    num_arg = 1;
  }
  global_of_mesh = new mgoptOF( num_arg, some );
}

void close_reader() {
  delete global_of_mesh;
}

void get_alloc_sizes( int *nNodes, int *nElems, int *nBnds, int *nBfaces ) {
  *nNodes = global_of_mesh->mesh()->points().size();
  *nElems = global_of_mesh->mesh()->cells().size();
  *nBnds = global_of_mesh->mesh()->boundaryMesh().size();
  *nBfaces = 0;
  for( int i = 0; i < *nBnds; ++i )
    *nBfaces += global_of_mesh->mesh()->boundaryMesh()[i].size();
} 

void get_node_coordinates( int *nNodes, double *x ) {
  for( int i = 0; i < *nNodes; ++i ) {
    for( int j = 0; j < 3; ++j ) {
      x[ i * 3 + j ] = global_of_mesh->mesh()->points()[i][j];
    }
  }
}

void get_cell_sizes_by_type( int *nCellType ) {
  /// Set all values to zero
  for( int i=0; i<MAX_ELT; ++i ) nCellType[i] = 0;
  /// Allowed cell types  
  const cellModel& tet = *(cellModeller::lookup("tet"));
  const cellModel& pyr = *(cellModeller::lookup("pyr"));
  const cellModel& prism = *(cellModeller::lookup("prism"));
  const cellModel& hex = *(cellModeller::lookup("hex"));
  /// Get the cell shapes
  const cellShapeList& cellShapes = global_of_mesh->mesh()->cellShapes();
  forAll(cellShapes, cellI)
  {
    const cellModel& model = cellShapes[cellI].model();
    if( model == tet )        nCellType[TET]++;
    else if( model == hex )   nCellType[HEX]++;
    else if( model == pyr )   nCellType[PYR]++;
    else if( model == prism ) nCellType[PRI]++;
    else
    {
      Foam::Info << "Unsupported 3d cell type in mgopt\n";
      Foam::FatalError.exit();
    } 
  }
  /// Count the tris' and quads'
  const polyBoundaryMesh& pbm = global_of_mesh->mesh()->boundaryMesh();
  forAll( pbm, ipatch )
  {
    const labelListList &fe = pbm[ipatch].faceEdges();
    for( int i = 0; i < fe.size(); ++i ) {
      if( fe[i].size() == 3 ) nCellType[TRI]++;
      else if( fe[i].size() == 4 ) nCellType[QUA]++;
      else
      {
        Foam::Info << "Unsupported 2d cell type in mgopt\n";
        Foam::FatalError.exit();
      }    
    }
  }
}

void get_bc_sizes_types
( 
   int *nWallInvWeak,
   int *nWallInvHard,
   int *nWallViscWeak,
   int *nWallViscHard,
   int *nInlet,
   int *nOutlet,
   int *nSymm,
   int *nManufactured,
   int *nParallel,
   int *patch2type,
   int *bnd2pg,
   int *pg2bnd
)
{
  Foam::wordList basicTypes =
        global_of_mesh->mesh()->boundaryMesh().types();
  Foam::wordList physicalTypes =
        global_of_mesh->mesh()->boundaryMesh().physicalTypes();
  /// Init the values
  *nWallInvWeak  = 0;
  *nWallInvHard  = 0;
  *nWallViscWeak = 0;
  *nWallViscHard = 0;
  *nInlet        = 0;
  *nOutlet       = 0;
  *nSymm         = 0;
  *nManufactured = 0;
  *nParallel     = 0;
  /// Check the bc type
  forAll( basicTypes, itype )
  {
    if( basicTypes[itype] == "wall" ||
        basicTypes[itype] == "patch" ||
        basicTypes[itype] == "symmetry" )
    {
      if( physicalTypes[itype] == "inviscidWallWeak" ){
        *nWallInvWeak++;
        patch2type[itype] = INVISCID_WALL_WEAK;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "inviscidWallHard" ){
        *nWallInvHard++;
        patch2type[itype] = INVISCID_WALL_HARD;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "viscousWallWeak" ){
        *nWallViscWeak++;
        patch2type[itype] = VISCOUS_WALL_WEAK;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "viscousWallHard" ){
        *nWallViscHard++;
        patch2type[itype] = VISCOUS_WALL_HARD;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "inlet" ){
        *nInlet++;
        patch2type[itype] = SUBSONIC_INLET;  
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "subsonicInlet" ){
        *nInlet++;
        patch2type[itype] = SUBSONIC_INLET;  
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "outlet" ){
        *nOutlet++;
        patch2type[itype] = SUBSONIC_OUTLET;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "subsonicOutlet" ){
        *nOutlet++;
        patch2type[itype] = SUBSONIC_OUTLET;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "freestream" ){
//        *nFreestream++;
        patch2type[itype] = FREESTREAM;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "symmetry" ){
        *nSymm++;
        patch2type[itype] = SYMMETRY;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else if( physicalTypes[itype] == "manufactured" ){
        *nManufactured++;
        patch2type[itype] = MANUFACTURED;
        bnd2pg[itype] = itype + 1;
        pg2bnd[itype] = itype + 1;
      }
      else
      {
        Foam::Info << "Unknown physicalType \"" << physicalTypes[itype] << "\"\n";
        Foam::Info << "Note: You have to specify the mgopt bc explicitly in the OpenFOAM mesh\n";
        Foam::FatalError.exit();
      }
    }
    else if( basicTypes[itype] == "processor" )
    {
/*      Foam::Info << "\"processor\" bc is not implemented in mgopt!\n";
      Foam::Info << "Only serial cases can be run using this OF reader\n";
      Foam::FatalError.exit();*/
      *nParallel++;
      patch2type[itype] = PARALLELBC;
      bnd2pg[itype] = itype + 1;
      pg2bnd[itype] = itype + 1;
    }
    else
    {
      Foam::Info << "Unknow basic boundary type \"" << basicTypes[itype] << "\"\n";
      Foam::Info << "Maybe it is not implemented in mgopt\n";
      Foam::FatalError.exit();
    }
  }
}

void get_cell_node_connectivity
(
  int *tet_el2pg,
  int *tet_el2Nde,
  int *pyr_el2pg,
  int *pyr_el2Nde,
  int *prism_el2pg,
  int *prism_el2Nde,
  int *hex_el2pg,
  int *hex_el2Nde,
  int *tri_el2pg,
  int *tri_el2Nde,
  int *quad_el2pg,
  int *quad_el2Nde
){
  int nCellType[MAX_ELT];
  /// Set all values to zero
  for( int i=0; i<MAX_ELT; ++i ) nCellType[i] = 0;
  /// Allowed cell types
  const cellModel& tet = *(cellModeller::lookup("tet"));
  const cellModel& pyr = *(cellModeller::lookup("pyr"));
  const cellModel& prism = *(cellModeller::lookup("prism"));
  const cellModel& hex = *(cellModeller::lookup("hex"));
  /// Get the cell shapes
  const cellShapeList& cellShapes =
         global_of_mesh->mesh()->cellShapes();

  forAll(cellShapes, cellI) {
    const cellModel& model = cellShapes[cellI].model();
    /// Tet model
    if( model == tet ) {
      //// Copy element physical type
      tet_el2pg[ nCellType[TET] ] = 0;//nCellType[TET];
      //// Copy cell-node connectivity
      for( int i = 0; i < 4; ++i )
        tet_el2Nde[ nCellType[TET] * 4 + i ] = cellShapes[cellI][i] + 1; // +1 for FORTRAN indexing
      nCellType[TET]++;
    }
    /// Pyramid model
    else if( model == pyr ) {
      //// Copy element physical type 
      pyr_el2pg[ nCellType[PYR] ] = 0;//nCellType[PYR];
      //// Copy cell-node connectivity
      for( int i = 0; i < 5; ++i )
        pyr_el2Nde[ nCellType[PYR] * 5 + i ] = cellShapes[cellI][i] + 1;  // +1 for FORTRAN indexing
      nCellType[PYR]++;
    }
    /// Prism model
    else if( model == prism ) {
      //// Copy element physical type 
      prism_el2pg[ nCellType[PRI] ] = 0;//nCellType[PRI];
      //// Copy cell-node connectivity
      for( int i = 0; i < 6; ++i )
        prism_el2Nde[ nCellType[PRI] * 6 + i ] = cellShapes[cellI][i] + 1;  // +1 for FORTRAN indexing
      nCellType[PRI]++;
    }
    /// Hex model
    else if( model == hex ) {
      //// Copy element physical type
      hex_el2pg[ nCellType[HEX] ] = 0;//nCellType[HEX];
      //// Copy cell-node connectivity
      for( int i = 0; i < 8; ++i )
        hex_el2Nde[ nCellType[HEX] * 8 + i ] = cellShapes[cellI][i] + 1;  // +1 for FORTRAN indexing
      nCellType[HEX]++;
    }
    //// Unsupported element
    else{
      Foam::Info << "Unsupported 3d cell type in mgopt\n";
      Foam::FatalError.exit();
    } 
  }
  /// Count the tris' and quads'
  const polyBoundaryMesh& pbm = global_of_mesh->mesh()->boundaryMesh();
  forAll( pbm, ipatch ) {
    const labelListList &fe = pbm[ipatch].faceEdges();
    for( int i = 0; i < fe.size(); ++i ) {
      //// Triangle model
      if( fe[i].size() == 3 ) {
        //// Copy element physical type 
        tri_el2pg[ nCellType[TRI] ] = ipatch + 1;//nCellType[TRI];
        //// Copy cell-node connectivity
        for( int j = 0; j < 3; ++j )
          tri_el2Nde[ nCellType[TRI] * 3 + j ] = pbm[ipatch][i][j] + 1;  // +1 for FORTRAN indexing
        nCellType[TRI]++;
      }
      //// Quad model
      else if( fe[i].size() == 4 ) {
        //// Copy element physical type 
        quad_el2pg[ nCellType[QUA] ] = ipatch + 1;;//nCellType[QUA];
        //// Copy cell-node connectivity
        for( int j = 0; j < 4; ++j )
          quad_el2Nde[ nCellType[QUA] * 4 + j ] = pbm[ipatch][i][j] + 1;  // +1 for FORTRAN indexing
        nCellType[QUA]++;
      }
      //// Unsupported model
      else{
        Foam::Info << "Unsupported 2d cell type in mgopt\n";
        Foam::FatalError.exit();
      }    
    }
  }
}

void get_bc_face_node_connectivity
(
  int *pg,
  int *elem,
  int *bFace2nNodes,
  int *bFace2nodes
)
{
  int patchType, nBfaces = 0;
  /// Loop over all boundary patches
  forAll( global_of_mesh->mesh()->boundaryMesh(), itype ) {
    //// Loop over boundary patch faces
    forAll( global_of_mesh->mesh()->boundaryMesh()[itype], iface ){
       pg[nBfaces] = itype + 1; /// +1 for FORTRAN indexing
       bFace2nNodes[nBfaces] = global_of_mesh->mesh()->boundaryMesh()[itype][iface].size();
       for( int i=0; i<bFace2nNodes[nBfaces]; ++i )
         bFace2nodes[ nBfaces * 4 + i ] = global_of_mesh->mesh()->boundaryMesh()[itype][iface][i] + 1; /// +1 for FORTRAN indexing
       nBfaces++;
    }
  }
}

void shared_node_mpi_sizes
(
  int *nprocs, int *nxadj,
  int *nadjncy, int *nsnlist,
  int *nngid
){
  *nprocs  = global_of_mesh->proc_list().size();
  *nxadj   = global_of_mesh->proc_xadj().size();
  *nadjncy = global_of_mesh->proc_adjncy().size();
  *nsnlist = global_of_mesh->proc_snlist().size();
  *nngid   = global_of_mesh->node_gid().size();
}

void shared_node_mpi_shed
(
  int *procs, int *xadj,
  int *adjncy, int *snlist,
  int *ngid
){
  for( size_t i = 0; i < global_of_mesh->proc_list().size(); ++i )
    procs[i] = global_of_mesh->proc_list()[i];
  for( size_t i = 0; i < global_of_mesh->proc_xadj().size(); ++i )
    xadj[i] = global_of_mesh->proc_xadj()[i];
  for( size_t i = 0; i < global_of_mesh->proc_adjncy().size(); ++i )
    adjncy[i] = global_of_mesh->proc_adjncy()[i];
  {
    size_t i;
    auto iter = global_of_mesh->proc_snlist().begin();
    for( i = 0, iter = global_of_mesh->proc_snlist().begin();
         iter != global_of_mesh->proc_snlist().end();
         ++i, ++iter )
      snlist[i] = *iter;
  }
  for( size_t i = 0; i < global_of_mesh->node_gid().size(); ++i )
    ngid[i] = global_of_mesh->node_gid()[i];
}

void get_design_input( int *design, int *costfun, double *costval ){
  std::copy( global_of_mesh->design().begin(), global_of_mesh->design().end(), design );
  std::copy( global_of_mesh->costfun().begin(), global_of_mesh->costfun().end(), costfun );
  if( global_of_mesh->costval().size() > 0 )
    std::copy( global_of_mesh->costval().begin(), global_of_mesh->costval().end(), costval );
  else
    std::fill( costval, costval + 5, 0.0 );
}

/// Works correctly for both serial and parallel cases
void get_boundary_path( std::string &str ) {
  /// Create the const polyMesh boundary file path
  Foam::wordList comp = global_of_mesh->args()->rootPath().components();
  comp.append("constant");
  comp.append("polyMesh");
  Foam::fileName fcomp( comp );
  str = std::string(fcomp);
}

